/* lalalala comentario lalalala */
#include <stdio.h>

void main (void){

	print("Hola mundo\n");
}
