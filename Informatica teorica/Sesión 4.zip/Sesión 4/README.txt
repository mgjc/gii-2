Para hacer la compilación del .y:

bison -d *.y

Para hacer la compilación del .l:

lex *.l

Para compilar los archivos *.tab.c y *.yy.c:

gcc *.tab.c *yy.c -o <ejecutable> -lfl

en el caso de que la librería math.h sea incluida compilar añadiendo -lm al final de gcc ...
