#!/bin/bash

echo -e "\033[0;32mMuestra las primeras palabras de los lenguajes establecidos y copia a distintos ficheros las que pertenezcan a cada expresion"

egrep -x 'a*b*' minilenguaje_universal.txt >> lenguaje1.txt
egrep -x 'a*|b*' minilenguaje_universal.txt >> lenguaje2.txt
egrep -x 'ab*' minilenguaje_universal.txt >> lenguaje3.txt
egrep -x '(ab)*' minilenguaje_universal.txt >> lenguaje4.txt
