#!/bin/bash

echo -e "\033[0;32mMuestra las lineas que contienen la letra p"

grep -ni p elCamino.txt

echo -e "\033[0;32mElimina las lineas que esten en blanco"

sed /^$/d elCamino.txt

echo -e "\033[0;32mBusca los puntos en el texto, los marca y numera las lineas en donde estan"

grep -ni '\.' elCamino.txt

echo -e "\033[0;32mMuestra las lineas que contengan exactamente 3 letras g"

grep -n [^g]*g[^g]*g[^g]*g[^g]* elCamino.txt

echo -e "\033[0;32mMuestra las lineas que contienen palabras que empiezan por 'bo' o por 'm'"

grep -ni ^bo ^m elCamino.txt

echo -e "\033[0;32mMuestra las lineas que contienen un par de letras 'e'"

grep -n [^e]*e[^e]*e[^e]* elCamino.txt
